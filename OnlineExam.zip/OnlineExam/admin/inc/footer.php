 </section>
<section class="footeroption">
		<h2><?php echo "bdj29mominur.lictproject.com"; ?></h2>
	</section>
</div>
</body>
</html>